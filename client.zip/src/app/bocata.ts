export class Bocata {
    public _id: String;
    public name: String;
    public visible: Boolean = true;
    constructor(name: String) {
        this.name = name;
    }
}
