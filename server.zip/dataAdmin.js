const profilesAPI = ['SF'];
const rolesAPI = ['system','admin'];
module.exports={profilesAPI,rolesAPI};